from telethon.sync import TelegramClient , events
from telethon.tl.functions.channels import InviteToChannelRequest, JoinChannelRequest
from telethon.tl.types import InputPeerChannel
from telethon.tl.functions.channels import GetParticipantsRequest
from time import sleep
file = open('dema', 'a')
client = TelegramClient('dex1', 2192036, '3b86a67fc4e14bd9dcfc2f593e75c841')
client.connect()
ik = ['https://t.me/stevenalbaghdadichat']
for group in ik:
    members = client.iter_participants(group)
    for member in members:
        user = member.username
        if not user == None:
            file.write(user+'\n')

    sleep(5)