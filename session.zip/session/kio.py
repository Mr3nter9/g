def search_text_in_file(file_path, search_text):
    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

        for i, line in enumerate(lines):
            if search_text in line:
                print(f"Found '{search_text}' in line {i + 1}: {line.strip()}")


# مثال على الاستخدام
file_path = 'dema'
search_text = 'T_bn2'
search_text_in_file(file_path, search_text)